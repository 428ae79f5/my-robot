Thank u bruno ♥

get session code from this link

https://replit.com/@bobiztestbot/bobiza-qrcode
 
 

